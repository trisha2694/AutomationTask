import json
import boto3
import pytest
result={}
# result['status']='Success' 


def lambda_handler(event, context):
    x=10
    assert x == 10
