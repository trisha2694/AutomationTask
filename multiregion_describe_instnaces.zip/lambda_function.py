import json
import boto3
import pytest
result={}
# result['status']='Success' 

def readConfig(configFileName):
    try:
        # Opening JSON file
        f = open(configFileName,)
          
        # returns JSON object as 
        # a dictionary
        data = json.load(f)
        
        
        # Iterating through the json
        # list
        for region in data['regions']:
            print(region)
            # Calling describeInstance method 
            describeInstance(region)
            
        # result['status']='Success'  
        
        # Closing file
        f.close()
    except Exception as e:
        print("Error in [readConfig]"+str(e))
        result['status'] ='failed'
        result['errormsg'] = str(e)
        return result
    
def describeInstance(region):
    instance_id=[]
    client = boto3.client('ec2',region_name=region)
    try:
        response = client.describe_instances()
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                print(instance['InstanceId'])
                instance_id.append(instance['InstanceId'])
        if len(instance_id)>0:
            result[region]=instance_id
    
    except Exception as e:
        print("Error in [describeInstance]"+str(e)+" in region : "+region)
        result['status'] ='failed'
        result['errormsg'] = str(e)
        #return result
        # return { 'status' : 'failed', 'errormsg' : str(e)}
def test():
    assert result['status'] == 'Success'
def lambda_handler(event, context):
    configFileName='aws_region_config.json'
    # try:
    readConfig(configFileName)
    if 'errormsg' not in result.keys():
        result['status']='Success'
    test()    
    
    # except Exception as e:
    #     print("Error in [lambda_handler]"+str(e)+" in region : "+region)
    #     result['status'] ='failed'
    #     result['errormsg'] = str(e)
    # result['status']='Success'
    
   
    print(result)
    return result
